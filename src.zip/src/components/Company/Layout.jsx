import React,{useEffect} from 'react';
import './css/styles.css';
import { Outlet, Link ,useNavigate} from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faGauge, faArrowRightFromBracket, faBell, faBullhorn } from '@fortawesome/free-solid-svg-icons'
const Layout = () => {
  const navigate=useNavigate();
  const username=localStorage.getItem("cname");

  useEffect(()=>{
    if(localStorage.getItem("status")==="0"){
      navigate("/")
    }
  },[])



  function logout(){
      localStorage.removeItem("cname");
      localStorage.removeItem("email");
      localStorage.removeItem("cid");
      localStorage.setItem("status","0");
      navigate("/")
  }



  function close() {

    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
      document.body.classList.toggle('sb-sidenav-toggled');
      localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
    }
  }

  return (
    <div class="d-flex" id="wrapper">



      <div id="sidebar-wrapper" style={{ background: "#4e73df", fontFamily: "Nunito,-apple-system,BlinkMacSystemFont", fontSize: "15px" }} >
        {/* <div class="sidebar-heading " style={{background:"#4e73df",color:"white"}}>LOGO</div> */}
        <div className='google-font' style={{ background: "#4e73df", width: "240px", }} >
          <Link to="/Company" class="list-group-item list-group-item-action list-group-item-light p-3" style={{ background: "#4e73df", color: "white" }} ><FontAwesomeIcon icon={faGauge} /> Dashboard</Link>
          {/* <Link class="list-group-item list-group-item-action list-group-item-light p-3" style={{ background: "#4e73df", color: "white" }}>Vesting Table</Link> */}
          <Link to="/Company/Employees" class="list-group-item list-group-item-action list-group-item-light p-3" style={{ background: "#4e73df", color: "white" }}>Employees</Link>
          <Link class="list-group-item list-group-item-action list-group-item-light p-3" style={{ background: "#4e73df", color: "white" }} >ESOP Scheme</Link>
          <Link to="/Company/VestingPlans" class="list-group-item list-group-item-action list-group-item-light p-3" style={{ background: "#4e73df", color: "white" }} >Vesting Plans</Link>
          <Link class="list-group-item list-group-item-action list-group-item-light p-3" style={{ background: "#4e73df", color: "white" }} >Manage Valuation</Link>


          {/* <button class="list-group-item list-group-item-action list-group-item-light p-3 btn btn-secondary dropdown-toggle"  style={{background:"#4e73df",color:"white"}}   type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false">
    Dropdown button
  </button>
  <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="dropdownMenuButton2">
    <li><a class="dropdown-item" href="#">Action</a></li>
    <li><a class="dropdown-item" href="#">Another action</a></li>
    <li><a class="dropdown-item" href="#">Something else here</a></li>
    <li><hr class="dropdown-divider" /></li>
    <li><a class="dropdown-item" href="#">Separated link</a></li>
  </ul> */}


          <Link to="/Company/Profile" class="list-group-item list-group-item-action list-group-item-ligth p-3" style={{ background: "#4e73df", color: "white" }} >Company Profile</Link>
        </div>
      </div>


      <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
          <div class="container-fluid">
            <img onClick={close} id="sidebarToggle" src="https://i.stack.imgur.com/UydTk.png" style={{ cursor: "pointer" }} height={14} />
            <div class="nav" id="navbarSupportedContent">



              <span style={{ cursor: "pointer" }} data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrollingannounce" aria-controls="offcanvasScrolling" class="nav-link p-2 mt-1"><FontAwesomeIcon icon={faBullhorn} style={{ color: "#000", }} size="xl" /></span>

              <span style={{ cursor: "pointer" }} data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling" class="nav-link p-2 mt-1"><FontAwesomeIcon icon={faBell} style={{ color: "#000", }} size="xl" /></span>

              <a class="nav-link dropdown-toggle" style={{ color: "black" }} id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><button type="button" className="btn btn-dark shdw">{localStorage.getItem("cname")!=null ? localStorage.getItem("cname")[0] : localStorage.getItem("cname")}</button>
              </a>



              <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                <center>
                <Link to="/Company/Profile" class="dropdown-item"><b>Profile</b></Link>
                <div class="dropdown-divider"></div>
                <button class="btn btn-outline-danger "onClick={logout}>Logout <FontAwesomeIcon icon={faArrowRightFromBracket} /></button>
                </center></div>



            </div>
          </div>
        </nav>




        <div class="container-fluid">




          <div class="offcanvas offcanvas-end google-font" data-bs-scroll="true" style={{ fontSize: "15px", background: "rgba(255,255,255,0.06)", backdropFilter: "blur(15px)", borderStartStartRadius: "35px", borderEndStartRadius: "35px", border: "0.2px solid silver" }} data-bs-backdrop="false" tabindex="-1" id="offcanvasScrollingannounce" aria-labelledby="offcanvasScrollingLabel">
            <div class="offcanvas-header" style={{ background: "rgba(255,255,255,0.7)" }}>
              <h5 class="offcanvas-title" id="offcanvasScrollingLabel"><b><FontAwesomeIcon icon={faBullhorn} style={{ color: "#4e73df", }} size="lg" /> Announcement</b></h5>
              <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
              <div class="form-floating">
                <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style={{ height: "100px" }}></textarea>
                <label for="floatingTextarea2">Announcement</label>
                <br></br>
                <button className="btn btn-dark float-end">Notify</button>
              </div>


            </div>
          </div>







          <div class="offcanvas offcanvas-end google-font" data-bs-scroll="true" style={{ fontSize: "15px", background: "rgba(255,255,255,0.06)", backdropFilter: "blur(15px)", borderStartStartRadius: "35px", borderEndStartRadius: "35px", border: "0.2px solid silver" }} data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling" aria-labelledby="offcanvasScrollingLabel">
            <div class="offcanvas-header" style={{ background: "rgba(255,255,255,0.7)" }}>
              <h5 class="offcanvas-title" id="offcanvasScrollingLabel"><b><FontAwesomeIcon icon={faBell} style={{ color: "#4e73df", }} size="lg" /> Notifications</b></h5>
              <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">

              <div class="alert alert-primary alert-dismissible fade show text-dark" role="alert">
                <p><strong>Holy guacamole</strong><span class="float-end">time</span></p> You should check in on some of those fields below.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>



            </div>
          </div>



          <Outlet />
          {/* 
        <button type="button" class="btn btn-primary">Primary</button>
<button type="button" class="btn btn-secondary">Secondary</button>
<button type="button" class="btn btn-success">Success</button>
<button type="button" class="btn btn-danger">Danger</button>
<button type="button" class="btn btn-warning">Warning</button>
<button type="button" class="btn btn-info">Info</button>
<button type="button" class="btn btn-light">Light</button>
<button type="button" class="btn btn-dark">Dark</button>

<button type="button" class="btn btn-link">Link</button> */}



        </div>
      </div>
    </div>
  )
}

export default Layout
